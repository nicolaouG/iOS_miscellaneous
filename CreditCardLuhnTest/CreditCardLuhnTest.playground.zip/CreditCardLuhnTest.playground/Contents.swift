import UIKit

extension String {
  var areAllCharactersNumbers: Bool {
    let nonNumberCharacterSet = CharacterSet.decimalDigits.inverted
    return (rangeOfCharacter(from: nonNumberCharacterSet) == nil)
  }
  
  var isLuhnValid: Bool {
    //https://www.rosettacode.org/wiki/Luhn_test_of_credit_card_numbers
    
    guard areAllCharactersNumbers else { return false }
    
    let reversed = self.reversed().map { String($0) }
    
    var sum = 0
    for (index, element) in reversed.enumerated() {
      guard let digit = Int(element) else {
        //This is not a number.
        return false
      }
      
      if index % 2 == 1 {
        //Even digit
        switch digit {
        case 9:
          //Just add nine.
          sum += 9
        default:
          //Multiply by 2, then take the remainder when divided by 9 to get addition of digits.
          sum += ((digit * 2) % 9)
        }
      } else {
        //Odd digit
        sum += digit
      }
    }
    
    //Valid if divisible by 10
    return sum % 10 == 0
  }
}



let eg1 = "4444444444444441"
let eg4 = "4444444444444444"
let eg8 = "4444444444444448"

eg1.isLuhnValid
eg4.isLuhnValid
eg8.isLuhnValid
